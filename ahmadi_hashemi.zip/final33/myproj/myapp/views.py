from django.shortcuts import render
import heapq
from collections import Counter

# Step 1: Implementing Burrows-Wheeler Transform (BWT)
def bwt_transform(input_string):
    input_string += "$"  # Append special end-of-string character
    rotations = [input_string[i:] + input_string[:i] for i in range(len(input_string))]
    sorted_rotations = sorted(rotations)
    bwt_result = ''.join(rotation[-1] for rotation in sorted_rotations)
    return bwt_result

# Step 2: Decoding the Burrows-Wheeler Transform (BWT)
def bwt_dcode(input_string):
    n = len(input_string)
    table = ["" for _ in range(n)]

    for _ in range(n):
        table = sorted([input_string[i] + table[i] for i in range(n)])

    for row in table:
        if row.endswith("$"):
            return row[:-1]  # Remove the end-of-string character

def bwt_decode(encoded):
    
    n = len(encoded)
    # Initialize the table for building the rows
    table = [""] * n

    for _ in range(n):
        # Prepend the encoded characters to the rows and sort them
        table = sorted([encoded[i] + table[i] for i in range(n)])

    # Find the row that ends with the end-of-string character '$'
    for row in table:
        if row.endswith("$"):
            return row.rstrip("$")

# Step 3: Run-Length Encoding (RLE)
def run_length_encode(input_string):
    encoded = []
    count = 1

    for i in range(1, len(input_string)):
        if input_string[i] == input_string[i - 1]:
            count += 1
        else:
            encoded.append(input_string[i - 1] + str(count))
            count = 1

    encoded.append(input_string[-1] + str(count))  # Add the last run
    return ''.join(encoded)

import heapq
from collections import defaultdict

class Node:
    def __init__(self, char, freq):
        self.char = char
        self.freq = freq
        self.left = None
        self.right = None

    def __lt__(self, other):
        return self.freq < other.freq

def build_huffman_tree(s):
    freq = defaultdict(int)
    for char in s:
        freq[char] += 1

    heap = [Node(char, f) for char, f in freq.items()]
    heapq.heapify(heap)

    while len(heap) > 1:
        left = heapq.heappop(heap)
        right = heapq.heappop(heap)
        merged = Node(None, left.freq + right.freq)
        merged.left = left
        merged.right = right
        heapq.heappush(heap, merged)

    return heap[0]  

def build_huffman_codes(root):
    huffman_codes = {}

    def encode(node, code):
        if not node:
            return
        if node.char is not None:
            huffman_codes[node.char] = code
        encode(node.left, code + "0")
        encode(node.right, code + "1")

    encode(root, "")
    return huffman_codes

def huffman_encoding(s):
    if not s:
        return {}, ""

    root = build_huffman_tree(s)
    huffman_codes = build_huffman_codes(root)
    encoded_string = "".join(huffman_codes[char] for char in s)
    return huffman_codes, encoded_string

# View Function
def process_text(request):
    result = {}
    if request.method == 'POST':
        input_text = request.POST.get('input_text', '')

        # Step 1: BWT
        bwt_result = bwt_transform(input_text)
        result['bwt'] = bwt_result

        # Step 2: Decode BWT
        original_text = bwt_decode(input_text)
        result['decoded'] = original_text

        # Step 3: RLE
        rle_result = run_length_encode(bwt_result)
        result['rle'] = rle_result

        # Step 4: Huffman Coding
        huffman_encoded, huffman_codes = huffman_encoding(input_text)
        result['huffman_encoded'] = huffman_encoded
        result['huffman_codes'] = huffman_codes

    return render(request, 'myapp/myapp.html', {'result': result})
